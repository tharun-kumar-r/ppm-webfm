<?php 
require_once "shared/header.php";
?>

<h1>dwferhtyu</h1>



<?php
require_once 'shared/footer.php';
?>