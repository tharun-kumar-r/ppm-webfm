<?php
if (!defined('BASEPATH')) {
    header('Location:/404');
  }

?>
<!-- Script Files -->
<?php echo Config::IMPORT['footer'] . Config::IMPORT['appJs']; ?>
    